declare module "*.png";
declare module "*.svg";
declare module "*.jpeg";
declare module "*.jpg";
declare module "*.gif";
declare module "*.webp";
declare module "*.webm";
declare module "*.mp4";